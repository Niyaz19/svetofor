package com.example.traffic_lights

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
